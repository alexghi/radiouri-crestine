chrome.runtime.onInstalled.addListener(() => {
  console.log("Radio Crestin extension installed");
});
chrome.action.onClicked.addListener((tab) => {
  console.log("Extension icon clicked");
});
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === "GET_CURRENT_TAB") {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      sendResponse({ tab: tabs[0] });
    });
    return true;
  }
  if (message.type === "OPEN_WEBSITE") {
    chrome.tabs.create({ url: "https://radiocrestin.ro" });
  }
});
