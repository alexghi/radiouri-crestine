let offscreenCreating = false;
let offscreenReady = false;
async function createOffscreenDocument() {
  const existingContexts = await chrome.runtime.getContexts({
    contextTypes: ["OFFSCREEN_DOCUMENT"]
  });
  if (existingContexts.length > 0) {
    console.log("Offscreen document already exists");
    offscreenReady = true;
    return;
  }
  if (offscreenCreating) {
    return;
  }
  offscreenCreating = true;
  try {
    await chrome.offscreen.createDocument({
      url: "offscreen.html",
      reasons: ["AUDIO_PLAYBACK"],
      justification: "Keep audio playing when extension popup is closed"
    });
    console.log("Offscreen document created");
  } catch (error) {
    console.error("Error creating offscreen document:", error);
  } finally {
    offscreenCreating = false;
  }
}
let pendingMessages = /* @__PURE__ */ new Map();
let messageId = 0;
async function sendMessageToOffscreen(message) {
  if (!offscreenReady) {
    await createOffscreenDocument();
    await new Promise((resolve) => setTimeout(resolve, 500));
  }
  const id = ++messageId;
  message.messageId = id;
  return new Promise((resolve, reject) => {
    pendingMessages.set(id, resolve);
    setTimeout(() => {
      if (pendingMessages.has(id)) {
        pendingMessages.delete(id);
        reject(new Error("Message timeout"));
      }
    }, 5e3);
    chrome.runtime.sendMessage(message).catch(() => {
      if (pendingMessages.has(id)) {
        pendingMessages.delete(id);
        reject(new Error("Failed to send message"));
      }
    });
  });
}
function updateBadge(isPlaying) {
  if (isPlaying) {
    chrome.action.setBadgeText({ text: "♪" });
    chrome.action.setBadgeBackgroundColor({ color: "#9333ea" });
  } else {
    chrome.action.setBadgeText({ text: "" });
  }
}
chrome.runtime.onInstalled.addListener(() => {
  console.log("Radio Crestin extension installed");
});
chrome.action.onClicked.addListener((tab) => {
  console.log("Extension icon clicked");
});
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  var _a, _b;
  console.log("Background received message:", message.type, "from:", sender.url);
  if (message.type === "AUDIO_LOAD_STATION" || message.type === "AUDIO_PLAY" || message.type === "AUDIO_PAUSE" || message.type === "AUDIO_SET_VOLUME" || message.type === "AUDIO_SET_MUTED" || message.type === "AUDIO_GET_STATE") {
    if ((_a = sender.url) == null ? void 0 : _a.includes("popup.html")) {
      sendMessageToOffscreen(message).then((response) => {
        sendResponse(response);
      }).catch((error) => {
        sendResponse({ success: false, error: error.message });
      });
      return true;
    }
  }
  if (message.type === "OFFSCREEN_RESPONSE" && message.messageId) {
    const resolver = pendingMessages.get(message.messageId);
    if (resolver) {
      pendingMessages.delete(message.messageId);
      resolver(message.response);
    }
    return;
  }
  if (message.type === "OFFSCREEN_READY") {
    console.log("Offscreen document is ready");
    offscreenReady = true;
    updateBadge(((_b = message.state) == null ? void 0 : _b.isPlaying) || false);
    return;
  }
  if (message.type === "AUDIO_STATE_CHANGED") {
    console.log("Audio state changed:", message.state);
    updateBadge(message.state.isPlaying);
    chrome.runtime.sendMessage({
      type: "BACKGROUND_AUDIO_STATE_CHANGED",
      state: message.state
    }).catch(() => {
    });
    return;
  }
  if (message.type === "SAVE_AUDIO_STATE") {
    chrome.storage.local.set({
      lastAudioState: message.state
    }).then(() => {
      sendResponse({ success: true });
    }).catch((error) => {
      console.error("Failed to save audio state:", error);
      sendResponse({ success: false, error: error.message });
    });
    return true;
  }
  if (message.type === "GET_AUDIO_STATE") {
    chrome.storage.local.get(["lastAudioState"]).then((result) => {
      sendResponse({ success: true, state: result.lastAudioState });
    }).catch((error) => {
      console.error("Failed to get audio state:", error);
      sendResponse({ success: false, error: error.message });
    });
    return true;
  }
  if (message.type === "GET_CURRENT_TAB") {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      sendResponse({ tab: tabs[0] });
    });
    return true;
  }
  if (message.type === "OPEN_WEBSITE") {
    chrome.tabs.create({ url: "https://radiocrestin.ro" });
  }
});
